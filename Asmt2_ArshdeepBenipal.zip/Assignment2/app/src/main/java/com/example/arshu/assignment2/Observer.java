package com.example.arshu.assignment2;

public interface Observer {
    void dataUpdated(String data);
}
